#! /bin/sh
# omp.sh
# start ompcnplat pdscpm pdsupm pdsdbio
source /etc/profile
curScriptPath=$(dirname $0)
omp_path=/zte/omp
DOG_PATH=/zte/ztecn

echo Start omp 
$omp_path/omp.sh start
sleep 1
echo start omp success

echo start cle
$curScriptPath/cle.sh start
sleep 1
echo start cle success

#echo start ztedog
#$DOG_PATH/ztedog.sh start
#sleep 1
#echo start ztedog success
