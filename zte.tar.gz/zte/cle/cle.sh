#! /bin/sh
# cle.sh
# start cle 

modname=cle
binname=uwb_${modname}
curScriptPath=$(dirname $0)

function usage()
{
    echo ====================
    echo "./${modname}.sh start"
    echo "./${modname}.sh stop"
    echo "./${modname}.sh restart"
    echo "./${modname}.sh kill-9"
    echo ====================
}

function start()
{
    process_id=`ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`
    
    if [ ! -z $process_id ];then
       echo  "${modname} is running!"
    else
       echo start ${modname}
       cd $curScriptPath
       $curScriptPath/${binname}
       echo start ${modname} success
    fi
}

function stop()
{
      echo stop ${modname}
	  killall ${binname}    
}

function restart()
{
    stop

    sleep 3
    
    start
}

case "$1" in
	"restart")
		restart;;
	"stop")
		stop;;
	"start")
		start;;
	"kill-9")
        kill -9 `ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`;;
	*)
		echo "parameter error!! ";
		echo "four parameters are valid----restart, start, stop, kill-9";;	
esac

