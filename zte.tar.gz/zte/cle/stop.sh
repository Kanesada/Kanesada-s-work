#! /bin/sh
# omp.sh
# stop ompcnplat pdscpm pdsupm pdsdbio

curScriptPath=$(dirname $0)
omp_path=/zte/omp
dog_path=/zte/ztecn

case "$1" in
	"kill-9")
		#echo now kill dog
		#$dog_path/ztedog.sh kill-9               
		echo now kill cle
		$curScriptPath/cle.sh kill-9      
		echo now kill omp
		$omp_path/omp.sh kill-9   ;;
	*)
		#$dog_path/ztedog.sh stop               
		$curScriptPath/cle.sh stop        
		$omp_path/omp.sh stop   ;;
esac

