#! /bin/sh
# omp.sh
# start ompcnplat 

modname=omp
binname=${modname}cnplat     #keep omp the same name with epc: ompcnplat
curScriptPath=$(dirname $0)

function usage()
{
    echo ====================
    echo "./${modname}.sh start"
    echo "./${modname}.sh stop"
    echo "./${modname}.sh restart"
    echo "./${modname}.sh kill-9"
    echo ====================
}

function start()
{
    process_id=`ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`
    if [ ! -z $process_id ];then
       echo  "${modname} is running!"
    else
       echo start ${modname}
       $curScriptPath/${binname}
       echo start ${modname} success
    fi    
}

function stop()
{
    CNT=1;
	process_id=`ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`
    echo "before stopping ompcnplat, the process_name is ${binname} and the process id is: $process_id"
    while  [ "$process_id" != ""  ] && [ $CNT -le 50 ]
    do
        kill $process_id
        process_id=`ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`
        CNT=`expr $CNT + 1`;      
    done
    if [ "$process_id" != "" ] && [ $CNT -gt 50 ];
    then
       echo "Can not stop ${modname} and try to kill it ... ";
       kill -9 `ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`;       
       CNT=1;
       process_id=`ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`
       while [ "$process_id" != ""  ] && [ $CNT -le 30 ]
       do
          process_id=`ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`
          CNT=`expr $CNT + 1`;
       done
       
       if [ "$process_id" != "" ] && [ $CNT -gt 30 ];
       then
          echo " CNT : $CNT ";
          echo "Can't kill ${modname} at last!"
       else
          echo " CNT : $CNT ";
          echo "Succeed in killing ${modname} at last!"
       fi
    else
        echo "Succeed in killing ${modname}."
    fi
}

function restart()
{
    stop
    start
}

case "$1" in
	"restart")
		restart;;
	"stop")
		stop;;
	"start")
		start;;
	"kill-9")
        kill -9 `ps -ef|grep /${binname}|grep -v '${binname}[a-z]'|grep -v 'grep'|awk '{print $2}'`;;
	*)
		echo "parameter error!! ";
		echo "four parameters are valid----restart, start, stop, kill-9";;	
esac

